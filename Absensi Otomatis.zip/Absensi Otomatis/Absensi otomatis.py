import cv2, os, numpy as np
import tkinter as tk
from PIL import ImageTk, Image
from datetime import datetime

def selesai1():
    instructions.config(text="Rekam Data Telah Selesai!", fg="#28a745")

def selesai2():
    instructions.config(text="Training Wajah Telah Selesai!", fg="#28a745")

def selesai3():
    instructions.config(text="Absensi Telah Dilakukan", fg="#28a745")

def rekamDataWajah():
    wajahDir = 'datawajah'
    os.makedirs(wajahDir, exist_ok=True)
    cam = cv2.VideoCapture(0)
    cam.set(3, 640)
    cam.set(4, 480)
    faceDetector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    faceID = entry2.get()
    nama = entry1.get()
    ambilData = 1
    while True:
        retV, frame = cam.read()
        abuabu = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = faceDetector.detectMultiScale(abuabu, 1.3, 5)
        for (x, y, w, h) in faces:
            frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            namaFile = f"{faceID}_{nama}_{ambilData}.jpg"
            cv2.imwrite(os.path.join(wajahDir, namaFile), frame)
            ambilData += 1
        cv2.imshow('Webcam', frame)
        if cv2.waitKey(1) & 0xFF == ord('q') or ambilData > 30:
            break
    selesai1()
    cam.release()
    cv2.destroyAllWindows()


def trainingWajah():
    wajahDir = 'datawajah'
    latihDir = 'latihwajah'

    def getImageLabel(path):
        imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
        faceSamples = []
        faceIDs = []
        for imagePath in imagePaths:
            PILimg = Image.open(imagePath).convert('L')
            imgNum = np.array(PILimg, 'uint8')
            faceID = int(os.path.split(imagePath)[-1].split('_')[0])
            faces = faceDetector.detectMultiScale(imgNum)
            for (x, y, w, h) in faces:
                faceSamples.append(imgNum[y:y + h, x:x + w])
                faceIDs.append(faceID)
            return faceSamples, faceIDs
    faceRecognizer = cv2.face.LBPHFaceRecognizer_create()
    faceDetector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    faces, IDs = getImageLabel(wajahDir)
    faceRecognizer.train(faces, np.array(IDs))
    # simpan
    faceRecognizer.write(latihDir + '/training.xml')
    selesai2()

def markAttendance(name):
    with open("Attendance.csv",'r+') as f:
        namesDatalist = f.readlines()
        namelist = []
        yournim = entry2.get()
        for line in namesDatalist:
            entry = line.split(',')
            namelist.append(entry[0])
        if name not in namelist:
            now = datetime.now()
            dtString = now.strftime('%H:%M:%S')
            f.writelines(f'\n{name},{yournim},{dtString}')

def absensiWajah():
    wajahDir = 'datawajah'
    latihDir = 'latihwajah'
    cam = cv2.VideoCapture(0)
    cam.set(3, 640)
    cam.set(4, 480)
    faceDetector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    faceRecognizer = cv2.face.LBPHFaceRecognizer_create()
    faceRecognizer.read(latihDir + '/training.xml')
    font = cv2.FONT_HERSHEY_SIMPLEX

    #id = 0
    yourname = entry1.get()
    names = []
    names.append(yourname)
    minWidth = 0.1 * cam.get(3)
    minHeight = 0.1 * cam.get(4)

    while True:
        retV, frame = cam.read()
        frame = cv2.flip(frame, 1)
        abuabu = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = faceDetector.detectMultiScale(abuabu, 1.2, 5, minSize=(round(minWidth), round(minHeight)), )
        for (x, y, w, h) in faces:
            frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0),2)
            id, confidence = faceRecognizer.predict(abuabu[y:y+h,x:x+w])
            if (confidence < 100):
                id = names[0]
                confidence = "  {0}%".format(round(150 - confidence))
            elif confidence < 50:
                id = names[0]
                confidence = "  {0}%".format(round(170 - confidence))

            elif confidence > 70:
                id = "Tidak Diketahui"
                confidence = "  {0}%".format(round(150 - confidence))

            cv2.putText(frame, str(id), (x + 5, y - 5), font, 1, (255, 255, 255), 2)
            cv2.putText(frame, str(confidence), (x + 5, y + h + 25), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)

        cv2.imshow('ABSENSI WAJAH', frame)

        if cv2.waitKey(1) & 0xFF == 13:  # jika menekan tombol enter akan berhenti
            break
    markAttendance(id)
    selesai3()
    cam.release()
    cv2.destroyAllWindows()

# GUI
root = tk.Tk()
root.title("Absensi Otomatis - Kehadiran Wajah")
root.geometry("700x500")
root.configure(bg="#242526")

# Judul
judul = tk.Label(root, text="Universitas Nasional", font=("Roboto", 24, "bold"), bg="#242526", fg="#28a745")
judul.pack(pady=20)

# Input Data
frame_input = tk.Frame(root, bg="#242526")
frame_input.pack(pady=20)

tk.Label(frame_input, text="Nama", font=("Roboto", 14), bg="#242526", fg="white").grid(row=0, column=0, padx=10, pady=5, sticky="w")
entry1 = tk.Entry(frame_input, font=("Roboto", 14), width=30)
entry1.grid(row=0, column=1, padx=10, pady=5)

tk.Label(frame_input, text="NIM", font=("Roboto", 14), bg="#242526", fg="white").grid(row=1, column=0, padx=10, pady=5, sticky="w")
entry2 = tk.Entry(frame_input, font=("Roboto", 14), width=30)
entry2.grid(row=1, column=1, padx=10, pady=5)

# Tombol
frame_buttons = tk.Frame(root, bg="#242526")
frame_buttons.pack(pady=20)

tk.Button(frame_buttons, text="Rekam Data", font=("Roboto", 12), bg="#28a745", fg="white", command=rekamDataWajah, width=15).grid(row=0, column=0, padx=10, pady=10)

tk.Button(frame_buttons, text="Training", font=("Roboto", 12), bg="#28a745", fg="white", command=trainingWajah, width=15).grid(row=0, column=1, padx=10, pady=10)

tk.Button(frame_buttons, text="Absensi", font=("Roboto", 12), bg="#28a745", fg="white", command=absensiWajah, width=15).grid(row=0, column=2, padx=10, pady=10)

# Instructions
instructions = tk.Label(root, text="Sistem Absensi Otomatis", font=("Roboto", 14), bg="#242526", fg="white")
instructions.pack(pady=20)

root.mainloop()